//
//  ViewController.h
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 05/02/2021.
//

#import <UIKit/UIKit.h>
#import <Realm.h>
#import "Reachability.h"
#import "JsonObject.h"
#import "listOfData.h"
#import "DetailsOfPosts_VC.h"
#import "ListOfPostsCell.h"

@interface ListOfPosts_VC: UIViewController <UITableViewDataSource,UITabBarControllerDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tblListOfPosts;
@property RLMResults<listOfData *> *objectsList;
@end

