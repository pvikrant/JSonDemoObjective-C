//
//  listOfData.h
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 07/02/2021.
//
#import <Realm/Realm.h>

@interface listOfData : RLMObject
// Add properties here to define the model
@property NSInteger userId;
@property NSInteger postId;
@property NSString  *title;
@property NSString    *body;

@end

// This protocol enables typed collections. i.e.:
// RLMArray<listOfData>
RLM_ARRAY_TYPE(listOfData)
