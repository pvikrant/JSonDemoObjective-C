//
//  JsonObject.m
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 08/02/2021.
//

#import "JsonObject.h"

@implementation JsonObject

+ (instancetype)getListOfPostsFromJSONString:(NSString *)JSONString
{
    if (self) {

        // START :Fetch response from json url and save into Realm database.
        NSData *jsonData=[NSData dataWithContentsOfURL:[NSURL URLWithString:JSONString]];
        NSError *error = nil;
        
        if (jsonData != nil){
            NSArray *listOfPostsDicts = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                   options:0
                                                                     error:&error];
            if (error) {
                NSLog(@"There was an error reading the JSON file: %@", error.localizedDescription);
            }
            RLMRealm *realm = [RLMRealm defaultRealm];
            [realm beginWriteTransaction];

            // START: Add post objects in realm for every post dictionary in JSON array
            for (NSDictionary *listOfPostsDict in listOfPostsDicts) {
                listOfData *postList = [[listOfData alloc] init];
                postList.title = listOfPostsDict[@"title"];
                postList.body = listOfPostsDict[@"body"];
                postList.postId = [listOfPostsDict[@"id"] integerValue];
                postList.userId = [listOfPostsDict[@"userId"] integerValue];
                [realm addObject:postList];
            }
            // END: Add post objects in realm for every post dictionary in JSON array
            [realm commitWriteTransaction];
            // END :Fetch response from json url and save into Realm database.
        }
    }
    return [[self alloc]init];
}
+ (instancetype)getListOfPostsDetailsFromJSONString:(NSString *)JSONString
{
    // START :Fetch response from json url and save into Realm database.
    NSData *jsonData=[NSData dataWithContentsOfURL:[NSURL URLWithString:JSONString]];
    NSError *error = nil;
    if (jsonData != nil){
        NSArray *detailsPostsDicts = [NSJSONSerialization JSONObjectWithData:jsonData
                                                               options:0
                                                                 error:&error];
        if (error) {
            NSLog(@"There was an error reading the JSON file: %@", error.localizedDescription);
        }
       
        RLMRealm *realm = [RLMRealm defaultRealm];
        [realm beginWriteTransaction];
        
        for (NSDictionary *detailsPostData in detailsPostsDicts) {
            
            //  START: Add post details objects in realm in NSDictionary
            detailsOfDataObject *detailsPost = [[detailsOfDataObject alloc] init];
            detailsPost.postId = [detailsPostData[@"id"] integerValue];
            detailsPost.name = detailsPostData[@"name"];
            detailsPost.userName = detailsPostData[@"username"];
            detailsPost.email = detailsPostData[@"email"];
            detailsPost.phone = detailsPostData[@"phone"];
            detailsPost.website = detailsPostData[@"website"];
            
            detailsPost.addressStreet = detailsPostData[@"address"][@"street"];
            detailsPost.addressSuite = detailsPostData[@"address"][@"suite"];
            detailsPost.addressCity = detailsPostData[@"address"][@"city"];
            detailsPost.addressZipcode = detailsPostData[@"address"][@"zipcode"];

            detailsPost.geoLat = detailsPostData[@"address"][@"geo"][@"lat"];
            detailsPost.geoLong = detailsPostData[@"address"][@"geo"][@"lng"];

            detailsPost.companyName = detailsPostData[@"company"][@"name"];
            detailsPost.companyCatchPhrase = detailsPostData[@"company"][@"catchPhrase"];
            detailsPost.companyBase = detailsPostData[@"company"][@"bs"];

            [realm addObject:detailsPost];
            //  END: Add post details objects in realm in NSDictionary
        }
        [realm commitWriteTransaction];
        
        // END :Fetch response from json url and save into Realm database.
    }
    return [[self alloc]init];
}

@end
