//
//  JsonObject.h
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 08/02/2021.
//

#import <Foundation/Foundation.h>
#import <Realm.h>
#import "listOfData.h"
#import "detailsOfDataObject.h"


NS_ASSUME_NONNULL_BEGIN

@interface JsonObject : NSObject
+ (instancetype)getListOfPostsFromJSONString:(NSString *)JSONString;
+ (instancetype)getListOfPostsDetailsFromJSONString:(NSString *)JSONString;
@end

NS_ASSUME_NONNULL_END
