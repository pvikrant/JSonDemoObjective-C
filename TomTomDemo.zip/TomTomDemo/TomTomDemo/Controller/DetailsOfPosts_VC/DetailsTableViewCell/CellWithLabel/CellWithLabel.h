//
//  CellWithLabel.h
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 05/02/2021.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CellWithLabel : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *viewOfHeader;
@property (weak, nonatomic) IBOutlet UIView *viewOfDetails;
@property (weak, nonatomic) IBOutlet UIView *viewOfAddress;
@property (weak, nonatomic) IBOutlet UIView *viewOfCompany;

@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblEmail;
@property (weak, nonatomic) IBOutlet UILabel *lblContact;
@property (weak, nonatomic) IBOutlet UILabel *lblWebsite;

@property (weak, nonatomic) IBOutlet UIStackView *bgStackView;
@property (weak, nonatomic) IBOutlet UILabel *lblAddress;
@property (weak, nonatomic) IBOutlet UILabel *lblPincode;

@property (weak, nonatomic) IBOutlet UILabel *lblCompanyName;
@property (weak, nonatomic) IBOutlet UILabel *lblCompanyWork;
@property (weak, nonatomic) IBOutlet UILabel *lblCompanyClient;

@end

NS_ASSUME_NONNULL_END
