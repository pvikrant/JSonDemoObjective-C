//
//  CellWithLabel.m
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 05/02/2021.
//

#import "CellWithLabel.h"

@implementation CellWithLabel

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
