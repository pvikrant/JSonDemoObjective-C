//
//  ViewController.m
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 05/02/2021.
//

#import "ListOfPosts_VC.h"

@interface ListOfPosts_VC ()
@end

@implementation ListOfPosts_VC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self getDataFromURL];
    [self.tblListOfPosts reloadData];
}

#pragma mark - Fetch data response from json and save into Realm database

-(void)getDataFromURL{
    
    if ([[Reachability reachabilityForInternetConnection]currentReachabilityStatus] == NotReachable)
    {
        _objectsList = [listOfData allObjects];
        if (_objectsList.count == 0)
        {
            // START: UIAlertController
            UIAlertController * alert = [UIAlertController
                                             alertControllerWithTitle:@"No Internet"
                                             message:@"Please connect internet first time and reopen app."
                                             preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction* noButton = [UIAlertAction
                                           actionWithTitle:@"Okay"
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action) {
                                               //Handle no, thanks button
                                           }];
            [alert addAction:noButton];

            [self presentViewController:alert animated:YES completion:nil];
            // END: UIAlertController
        }
    }
    else
    {
        // START: get list of posts from URL
        [JsonObject getListOfPostsFromJSONString:@"http://jsonplaceholder.typicode.com/posts"];
        // END: get list of posts from URL
        _objectsList = [listOfData allObjects];
    }
    [self.tblListOfPosts reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _objectsList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ListOfPostsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ListOfPostsCell" forIndexPath:indexPath];
    listOfData *thisCellObject = [_objectsList objectAtIndex:indexPath.row];
    cell.lblTitile.text = thisCellObject.title;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DetailsOfPosts_VC *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailsOfPosts_VC"];
    listOfData *thisCellObject = [_objectsList objectAtIndex:indexPath.row];
    VC.selectedUserId = thisCellObject.userId;
    VC.body = thisCellObject.body;
    [self.navigationController pushViewController:VC animated:YES];
}


@end
