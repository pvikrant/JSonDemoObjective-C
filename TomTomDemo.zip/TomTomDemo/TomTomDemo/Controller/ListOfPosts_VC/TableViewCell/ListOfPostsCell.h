//
//  ListOfPostsCell.h
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 05/02/2021.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ListOfPostsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitile;
@end

NS_ASSUME_NONNULL_END
