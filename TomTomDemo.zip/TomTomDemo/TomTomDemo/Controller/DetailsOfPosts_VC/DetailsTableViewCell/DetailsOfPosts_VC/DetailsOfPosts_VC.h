//
//  DetailsOfPosts_VC.h
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 05/02/2021.
//

#import <UIKit/UIKit.h>
#import <Realm.h>
#import "JsonObject.h"
#import "Reachability.h"
#import "CellWithLabel.h"
#import "detailsOfDataObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface DetailsOfPosts_VC : UIViewController <UITableViewDataSource,UITabBarControllerDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tblDetailsPosts;
@property RLMResults<detailsOfDataObject *> *objectsDatailsList;
@property NSInteger  selectedUserId;
@property NSString  *body;

@end

NS_ASSUME_NONNULL_END
