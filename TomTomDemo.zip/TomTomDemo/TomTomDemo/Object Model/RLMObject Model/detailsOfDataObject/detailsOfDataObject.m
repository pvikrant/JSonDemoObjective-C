//
//  detailsOfDataObject.m
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 07/02/2021.
//

#import "detailsOfDataObject.h"

@implementation detailsOfDataObject
@end
