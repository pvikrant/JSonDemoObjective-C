//
//  detailsOfDataObject.h
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 07/02/2021.
//

#import <Realm/Realm.h>

@interface detailsOfDataObject : RLMObject
// Add properties here to define the model
@property NSInteger  postId;
@property NSString  *name;
@property NSString    *userName;
@property NSString    *email;

@property NSString    *addressStreet;
@property NSString    *addressSuite;
@property NSString    *addressCity;
@property NSString    *addressZipcode;

@property NSString    *geoLat;
@property NSString    *geoLong;
@property NSString    *phone;
@property NSString    *website;

@property NSString    *companyName;
@property NSString    *companyCatchPhrase;
@property NSString    *companyBase;

@end

// This protocol enables typed collections. i.e.:
// RLMArray<detailsOfDataObject>\

RLM_ARRAY_TYPE(detailsOfDataObject)
