//
//  DetailsOfPosts_VC.m
//  TomTomDemo
//
//  Created by AppEdify TechnoWorld on 05/02/2021.
//

#import "DetailsOfPosts_VC.h"

@interface DetailsOfPosts_VC ()
@end

@implementation DetailsOfPosts_VC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self getDataFromURL];
}

-(void)viewWillAppear:(BOOL)animated
{
    [self.tblDetailsPosts reloadData];
}

#pragma mark - Fetch data response from json and save into Realm database

-(void)getDataFromURL{
    
    if ([[Reachability reachabilityForInternetConnection]currentReachabilityStatus]==NotReachable)
    {
        _objectsDatailsList = [detailsOfDataObject allObjects];
        
        if (_objectsDatailsList.count == 0)
        {
            // START: UIAlertController
            UIAlertController * alert = [UIAlertController
                                             alertControllerWithTitle:@"No Internet"
                                             message:@"Please connect internet first time and reopen app."
                                             preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction* noButton = [UIAlertAction
                                           actionWithTitle:@"Okay"
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action) {
                                               //Handle no, thanks button
                                           }];
            [alert addAction:noButton];

            [self presentViewController:alert animated:YES completion:nil];
            // END: UIAlertController
        }
        else
        {
            // START: Query Realm for filter post details according to selected post.
            NSString *someText = [NSString stringWithFormat: @"postId == %ld", (long)_selectedUserId];
            RLMResults<detailsOfDataObject *> *filter = [detailsOfDataObject objectsWhere:someText];
            _objectsDatailsList = filter;
            // END: Query Realm for filter post details according to selected post.
        }
    }
    else
    {
        // START: get post details from URL
        [JsonObject getListOfPostsDetailsFromJSONString:[NSString stringWithFormat:@"http://jsonplaceholder.typicode.com/users"]];
        // END: get post details from URL
        
        // START: Query Realm for filter post details according to selected post.
        NSString *someText = [NSString stringWithFormat: @"postId == %ld", (long)_selectedUserId];
        RLMResults<detailsOfDataObject *> *filter = [detailsOfDataObject objectsWhere:someText];
        _objectsDatailsList = filter;
        
        // END: Query Realm for filter post details according to selected post.
    }
    
    [self.tblDetailsPosts reloadData];
}

#pragma mark - IBAction

- (IBAction)btnBackAction:(id)sender {
   
    [self.navigationController popViewControllerAnimated:true];
}
#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return tableView.frame.size.height;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if (_objectsDatailsList.count != 0)
    {
        return 1;
    }
    return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    detailsOfDataObject *thisCellObject = [_objectsDatailsList objectAtIndex:indexPath.row];
    
    CellWithLabel *cell = [tableView dequeueReusableCellWithIdentifier:@"CellWithLabel" forIndexPath:indexPath];
    
//        cell.viewOfHeader.layer.cornerRadius = 10;
//        cell.viewOfHeader.clipsToBounds = YES;
    
        cell.lblName.text = thisCellObject.name;
        cell.lblEmail.text = [NSString stringWithFormat:@"Email: %@",thisCellObject.email];
        cell.lblContact.text = [NSString stringWithFormat:@"Contact: %@",thisCellObject.phone];
        cell.lblWebsite.text = [NSString stringWithFormat:@"Website: %@",thisCellObject.website];
        
        cell.lblAddress.text = [NSString
                                stringWithFormat:@"%@, %@, %@"
                            ,   thisCellObject.addressStreet
                            ,   thisCellObject.addressSuite,
                                thisCellObject.addressCity
                            ];
        
        cell.lblPincode.text = [NSString stringWithFormat:@"Zipcode: %@",thisCellObject.addressZipcode];
        
        cell.lblCompanyName.text = thisCellObject.companyName;
        cell.lblCompanyWork.text = thisCellObject.companyBase;
        cell.lblCompanyClient.text = thisCellObject.companyCatchPhrase;

    return cell;
}
@end
